package com.example.nammapustaka

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class BookAdapter(private val bookList: List<Book>) :
    RecyclerView.Adapter<BookAdapter.BookViewHolder>() {

    class BookViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val bookImage: ImageView = itemView.findViewById(R.id.bookImage)
        val bookTitle: TextView = itemView.findViewById(R.id.bookTitle)
        val bookAuthor: TextView = itemView.findViewById(R.id.bookAuthor)
        val bookCategory: TextView = itemView.findViewById(R.id.bookCategory)
        val favoriteIcon: ImageView = itemView.findViewById(R.id.favoriteIcon)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.book_item, parent, false)

        return BookViewHolder(view)
    }

    override fun onBindViewHolder(holder: BookViewHolder, position: Int) {

        val currentBook = bookList[position]

        holder.bookTitle.text = currentBook.title
        holder.bookAuthor.text = currentBook.author
        holder.bookCategory.text = currentBook.category

        holder.bookImage.setImageResource(currentBook.image)

        if (currentBook.isFavorite) {

            holder.favoriteIcon.setImageResource(
                android.R.drawable.btn_star_big_on
            )

        } else {

            holder.favoriteIcon.setImageResource(
                android.R.drawable.btn_star_big_off
            )
        }

        holder.favoriteIcon.setOnClickListener {

            currentBook.isFavorite = !currentBook.isFavorite

            notifyItemChanged(position)

        }

        holder.itemView.setOnClickListener {

            val intent = Intent(holder.itemView.context, DetailActivity::class.java)

            intent.putExtra("title", currentBook.title)
            intent.putExtra("author", currentBook.author)
            intent.putExtra("description", currentBook.description)
            intent.putExtra("image", currentBook.image)

            holder.itemView.context.startActivity(intent)

        }
    }

    override fun getItemCount(): Int {

        return bookList.size

    }
}