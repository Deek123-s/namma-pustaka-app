package com.example.nammapustaka

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_detail)

        val image = findViewById<ImageView>(R.id.detailImage)
        val title = findViewById<TextView>(R.id.detailTitle)
        val author = findViewById<TextView>(R.id.detailAuthor)
        val description = findViewById<TextView>(R.id.detailDescription)

        val borrowBtn = findViewById<Button>(R.id.borrowBtn)

        val bookTitle = intent.getStringExtra("title")
        val bookAuthor = intent.getStringExtra("author")
        val bookDescription = intent.getStringExtra("description")
        val bookImage = intent.getIntExtra("image", 0)

        title.text = bookTitle
        author.text = bookAuthor
        description.text = bookDescription

        image.setImageResource(bookImage)

        borrowBtn.setOnClickListener {

            Toast.makeText(
                this,
                "Book Borrowed Successfully",
                Toast.LENGTH_SHORT
            ).show()

        }
    }
}