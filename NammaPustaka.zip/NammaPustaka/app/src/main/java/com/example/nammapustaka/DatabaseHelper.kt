package com.example.nammapustaka

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "LibraryDB", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {

        val createTable = """
            
            CREATE TABLE books (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT,
                author TEXT,
                category TEXT
            )
            
        """.trimIndent()

        db.execSQL(createTable)
    }

    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {

        db.execSQL("DROP TABLE IF EXISTS books")

        onCreate(db)
    }

    fun insertBook(
        title: String,
        author: String,
        category: String
    ): Boolean {

        val db = writableDatabase

        val values = ContentValues()

        values.put("title", title)
        values.put("author", author)
        values.put("category", category)

        val result = db.insert("books", null, values)

        return result != -1L
    }
}