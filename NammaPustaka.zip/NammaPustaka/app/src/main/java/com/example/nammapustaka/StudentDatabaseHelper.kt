package com.example.nammapustaka

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class StudentDatabaseHelper(context: Context) :

    SQLiteOpenHelper(
        context,
        "StudentDB",
        null,
        1
    ) {

    override fun onCreate(db: SQLiteDatabase) {

        db.execSQL(
            "CREATE TABLE students (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "name TEXT," +
                    "usn TEXT," +
                    "course TEXT," +
                    "phone TEXT," +
                    "email TEXT)"
        )
    }

    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {

        db.execSQL("DROP TABLE IF EXISTS students")

        onCreate(db)
    }

    fun insertStudent(
        name: String,
        usn: String,
        course: String,
        phone: String,
        email: String
    ): Boolean {

        val db = this.writableDatabase

        val values = ContentValues()

        values.put("name", name)
        values.put("usn", usn)
        values.put("course", course)
        values.put("phone", phone)
        values.put("email", email)

        val result = db.insert(
            "students",
            null,
            values
        )

        return result != -1L
    }
}