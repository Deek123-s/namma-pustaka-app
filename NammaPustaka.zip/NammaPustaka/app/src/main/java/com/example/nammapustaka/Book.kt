package com.example.nammapustaka

data class Book(

    val title: String,
    val author: String,
    val image: Int,
    val description: String,
    val category: String,
    var isFavorite: Boolean = false

)