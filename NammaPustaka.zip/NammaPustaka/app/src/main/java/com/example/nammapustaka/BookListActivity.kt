package com.example.nammapustaka

import android.os.Bundle
import android.widget.Button
import android.widget.SearchView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

class BookListActivity : AppCompatActivity() {

    private lateinit var adapter: BookAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var bookList: List<Book>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_book_list)

        recyclerView = findViewById(R.id.recyclerView)

        recyclerView.layoutManager = GridLayoutManager(this, 2)

        bookList = listOf(

            Book(
                "Atomic Habits",
                "James Clear",
                R.drawable.book1,
                "A powerful book about building good habits.",
                "Motivation"
            ),

            Book(
                "Brief History of Time",
                "Stephen Hawking",
                R.drawable.book2,
                "Science and space book.",
                "Science"
            ),

            Book(
                "Wings of Fire",
                "A.P.J Abdul Kalam",
                R.drawable.book3,
                "Biography of Abdul Kalam.",
                "Biography"
            ),

            Book(
                "Indian History",
                "Bipan Chandra",
                R.drawable.book4,
                "Indian history book.",
                "History"
            ),

            Book(
                "Kannada Sahitya",
                "Kuvempu",
                R.drawable.book1,
                "Kannada literature book.",
                "Kannada"
            )

        )

        adapter = BookAdapter(bookList)

        recyclerView.adapter = adapter

        val allBtn = findViewById<Button>(R.id.allBtn)
        val motivationBtn = findViewById<Button>(R.id.motivationBtn)
        val scienceBtn = findViewById<Button>(R.id.scienceBtn)
        val historyBtn = findViewById<Button>(R.id.historyBtn)
        val kannadaBtn = findViewById<Button>(R.id.kannadaBtn)
        val biographyBtn = findViewById<Button>(R.id.biographyBtn)

        allBtn.setOnClickListener {
            adapter = BookAdapter(bookList)
            recyclerView.adapter = adapter
        }

        motivationBtn.setOnClickListener {
            filterBooks("Motivation")
        }

        scienceBtn.setOnClickListener {
            filterBooks("Science")
        }

        historyBtn.setOnClickListener {
            filterBooks("History")
        }

        kannadaBtn.setOnClickListener {
            filterBooks("Kannada")
        }

        biographyBtn.setOnClickListener {
            filterBooks("Biography")
        }

        val searchView = findViewById<SearchView>(R.id.searchView)

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {

                searchBooks(newText)

                return true
            }
        })
    }

    private fun filterBooks(category: String) {

        val filteredList = bookList.filter {

            it.category == category

        }

        adapter = BookAdapter(filteredList)

        recyclerView.adapter = adapter
    }

    private fun searchBooks(text: String?) {

        val filteredList = bookList.filter {

            it.title.lowercase(Locale.getDefault())
                .contains(text.toString().lowercase(Locale.getDefault()))

        }

        adapter = BookAdapter(filteredList)

        recyclerView.adapter = adapter
    }
}