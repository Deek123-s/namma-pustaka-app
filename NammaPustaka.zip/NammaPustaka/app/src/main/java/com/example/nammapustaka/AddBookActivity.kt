package com.example.nammapustaka

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AddBookActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_add_book)

        val titleEt = findViewById<EditText>(R.id.titleEt)
        val authorEt = findViewById<EditText>(R.id.authorEt)
        val categoryEt = findViewById<EditText>(R.id.categoryEt)

        val saveBtn = findViewById<Button>(R.id.saveBtn)

        val db = DatabaseHelper(this)

        saveBtn.setOnClickListener {

            val title = titleEt.text.toString()
            val author = authorEt.text.toString()
            val category = categoryEt.text.toString()

            val success = db.insertBook(
                title,
                author,
                category
            )

            if (success) {

                Toast.makeText(
                    this,
                    "Book Saved",
                    Toast.LENGTH_SHORT
                ).show()

            } else {

                Toast.makeText(
                    this,
                    "Failed",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}