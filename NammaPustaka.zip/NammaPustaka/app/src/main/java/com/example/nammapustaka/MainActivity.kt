package com.example.nammapustaka

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        val viewBooksBtn = findViewById<Button>(R.id.viewBooksBtn)

        val addBookBtn = findViewById<Button>(R.id.addBookBtn)

        val qrBtn = findViewById<Button>(R.id.qrBtn)

        val aboutBtn = findViewById<Button>(R.id.aboutBtn)

        val profileBtn = findViewById<Button>(R.id.profileBtn)

        viewBooksBtn.setOnClickListener {

            startActivity(
                Intent(this, BookListActivity::class.java)
            )
        }

        addBookBtn.setOnClickListener {

            startActivity(
                Intent(this, AddBookActivity::class.java)
            )
        }

        qrBtn.setOnClickListener {

            startActivity(
                Intent(this, QrScannerActivity::class.java)
            )
        }

        aboutBtn.setOnClickListener {

            startActivity(
                Intent(this, AboutActivity::class.java)
            )
        }

        profileBtn.setOnClickListener {

            startActivity(
                Intent(this, ProfileActivity::class.java)
            )
        }
    }
}