package com.example.nammapustaka

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_profile)

        val nameEt =
            findViewById<EditText>(R.id.nameEt)

        val usnEt =
            findViewById<EditText>(R.id.usnEt)

        val courseEt =
            findViewById<EditText>(R.id.courseEt)

        val phoneEt =
            findViewById<EditText>(R.id.phoneEt)

        val emailEt =
            findViewById<EditText>(R.id.emailEt)

        val registerBtn =
            findViewById<Button>(R.id.registerBtn)

        val db =
            StudentDatabaseHelper(this)

        registerBtn.setOnClickListener {

            val success = db.insertStudent(

                nameEt.text.toString(),

                usnEt.text.toString(),

                courseEt.text.toString(),

                phoneEt.text.toString(),

                emailEt.text.toString()

            )

            if (success) {

                Toast.makeText(
                    this,
                    "Profile Registered Successfully",
                    Toast.LENGTH_SHORT
                ).show()

            } else {

                Toast.makeText(
                    this,
                    "Failed",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}