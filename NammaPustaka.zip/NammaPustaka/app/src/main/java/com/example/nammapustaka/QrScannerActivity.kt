package com.example.nammapustaka

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class QrScannerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_qr_scanner)

        val scanBtn = findViewById<Button>(R.id.scanBtn)

        scanBtn.setOnClickListener {

            Toast.makeText(
                this,
                "QR Code Scanned Successfully",
                Toast.LENGTH_SHORT
            ).show()

        }
    }
}